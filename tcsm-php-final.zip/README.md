# TCsM Portfolio (PHP)

## Run locally
    php -S localhost:8000      # from this folder, then open http://localhost:8000
or copy the folder into XAMPP's `htdocs/` and open `http://localhost/tcsm-php/`.

## Where to edit content
All text lives in `data/` (site.php, projects.php, about.php). Add a mission by adding one array item in `data/projects.php`.

## Contact form
`send.php` validates (CSRF token, honeypot, 30 s rate limit, header-injection stripping), writes every message to `storage/transmissions.log`, and calls `mail()` to `MAIL_TO` in `includes/config.php`.
- XAMPP/localhost: `mail()` needs sendmail/SMTP configured; otherwise messages are still saved in the log.
- Web host (cPanel etc.): set `MAIL_FROM` to an address on your own domain so mail isn't flagged as spam.

## Structure
includes/ (config, helpers, header, footer) · data/ · css/ · js/ · images/ · fonts/ · storage/
